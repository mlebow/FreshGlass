1. Use an Apple computer. 
2. Make sure internet works, or some elements that rely on internet services may not load.
3. Open Kinoma Studio, import freshglassapp and freshglassdevice files.
4. For the freshglassdevice: Set the simulator in its application.xml to  Kinoma Create
5. For the freshglassapp: Set the simulator in its application.xml to iPhone 4 
6. Run the freshglassdevice simulator
7. Run the freshglassapp simulator
